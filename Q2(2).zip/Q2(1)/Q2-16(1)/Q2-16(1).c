#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{
	int x;
	int y;
	int prod;

	scanf("%d", &x);
	scanf("%d", &y);
	prod = x * y;

	printf("������ ���=%d", prod);

	return 0;
}
